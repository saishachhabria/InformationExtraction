#!/usr/bin/env bash
echo "Google bought IBM for 10 dollars." > samples.txt
python main.py -f samples.txt -v
